#include "AVLInterface.h"
#include "Node.h"
#include <iostream>
using namespace std;

class AVL : public AVLInterface {
public:
    AVL() {
        root = NULL;
    }
    ~AVL(){
        clear();
    }
    NodeInterface * getRootNode() const;
    bool add(int item);
    bool add(Node*& local_root, int item);
    bool remove(int item);
    bool remove(Node*& local_root, int item);
    void clear();
    void clear(Node*& local_root);
    void replace_parent(Node*& old_root, Node*& local_root);
    void balance(Node*& local_root);
    void rotate_right(Node*& n);
    void rotate_left(Node*& n);
    
protected:
    Node *root;
};