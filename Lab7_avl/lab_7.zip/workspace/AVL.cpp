#include "AVL.h"
	NodeInterface * AVL::getRootNode() const{
	    return root;
	}
	bool AVL::add(int item){
		return add(this->root, item);
	}
	bool AVL::add(Node*& local_root, const int item){
		bool result;
		
		if (local_root == NULL) {
			local_root = new Node(item);
    		return true;
		}
		else {
    		if (item < local_root->data){
    			result = add(local_root->leftChild, item);
//    			cout << "before balance of item " << item << endl;
				balance(local_root);
//				cout << "after balance" << endl;
				return (result);
    		}
    		else if (local_root->data < item){
    			result = add(local_root->rightChild, item);
//    			cout << "before balance" << endl;
    			balance(local_root);
//    			cout << "after balance local_root is " << local_root->data << endl;
//    			cout << "after balance local_root rightChild is " << local_root->rightChild->data << endl;
    			
    			return (result);
    		}
			else {
				return false;
			}
			
		}
		return result;
	}
	bool AVL::remove(int item){
	    return remove(this->root, item);
	    
	}
	bool AVL::remove(Node*& local_root, int item){
		if (local_root == NULL) {
			return false;
		}
		else {
			if (item < local_root->data){
				bool result = remove(local_root->leftChild, item);
				balance(local_root);
		    	return (result);
			}
		    else if (local_root->data < item){
		    	bool result = remove(local_root->rightChild, item);
		    	balance(local_root);
		    	return (result);
		    }
		    else {
		    	Node* old_root = local_root;
		    	if (local_root->leftChild == NULL) {
		    		local_root = local_root->rightChild;
		    	}
		    	else if (local_root->rightChild == NULL) {
		        	local_root = local_root->leftChild;
		        	balance(local_root);
		    	}
		    	else {
		        	replace_parent(old_root, old_root->leftChild);
		        	balance(local_root);
		    	}
				delete old_root;      
				return true;
			}
		}
	}
	void AVL::replace_parent(Node*& old_root, Node*& local_root) {
		if (local_root->rightChild != NULL) {
			replace_parent(old_root, local_root->rightChild);
			balance(local_root);
		}
		else {
			old_root->data = local_root->data;
			old_root = local_root;
			local_root = local_root->leftChild;
		}
	}
	void AVL::clear(){
	    clear(root);
	}
	void AVL::clear(Node*& root){
		while(root != NULL){
			remove(root->data);
		}
	}
	void AVL::balance(Node*& n){
		int left;
		int right;
		if (n->leftChild != NULL){
			left = n->leftChild->getHeight();
		}
		else {
			left = 0;
		}
		if (n->rightChild != NULL){
			right = n->rightChild->getHeight();
		}
		else {
			right = 0;
		}
//cout << "At Node " << n->data << " left is " << left << " and right is " << right << endl;
		int balance = right - left;
		
		if (balance == -2){
			if(n->leftChild->rightChild == NULL){
//cout << "LL with rightChild=NULL" << endl;
				rotate_right(n);
			}
			else if(n->leftChild->leftChild == NULL){
//cout << "LR with leftChild=NULL" << endl;
				rotate_left(n->leftChild);
        		rotate_right(n);	
			}
			else if(n->leftChild->rightChild->getHeight() <= n->leftChild->leftChild->getHeight()){//LL
			//rotate_right(around parent)
//cout << "LL " << endl;
				rotate_right(n);
			}
			else if(n->leftChild->rightChild->getHeight() > n->leftChild->leftChild->getHeight()){//LR
				//rotate_left(around left child);
				//rotate_right(around parent);
//cout << "LR " << endl;
				rotate_left(n->leftChild);
        		rotate_right(n);
			}
		} 
		if (balance == 2){
			if(n->rightChild->leftChild == NULL ){
//cout << "RR with leftChild=NULL" << endl;
				rotate_left(n);
			}
			else if(n->rightChild->rightChild == NULL){
//cout << "RL with rightChild=NULL" << endl;
				rotate_right(n->rightChild);
        		rotate_left(n);
			}
			else if(n->rightChild->leftChild->getHeight() <= n->rightChild->rightChild->getHeight()){//RR
//cout << "RR " << endl;
				rotate_left(n);
			}
			else if(n->rightChild->leftChild->getHeight() > n->rightChild->rightChild->getHeight()){//RL
//cout << "RL " << endl;
				rotate_right(n->rightChild);
        		rotate_left(n);
			}
		}
		
	}
	void AVL::rotate_right(Node*& n){
		Node* temp = n->leftChild;
    	n->leftChild = temp->rightChild;
    	temp->rightChild = n;
    	n = temp;
    	// cout << "n is " << n->data<< endl;
    	// cout << "n left " << n->leftChild->data<< endl;
    	// cout << "n right " << n->rightChild->data<< endl;
	}
	void AVL::rotate_left(Node*& n){
		Node* temp = n->rightChild;
    	n->rightChild = temp->leftChild;
    	temp->leftChild = n;
    	n = temp;
    	// cout << "n is " << n->data<< endl;
    	// cout << "n left " << n->leftChild->data<< endl;
    	// cout << "n right " << n->rightChild->data<< endl;
	}