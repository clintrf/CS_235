#include "Node.h"
#include <algorithm>
	int Node::getData() const{
	    return(data);
	}
	NodeInterface * Node::getLeftChild() const{
	      if (leftChild == NULL){
	      	return NULL;
	      }
	      return(leftChild);
	}
	NodeInterface * Node::getRightChild() const{
	      if (rightChild == NULL){
	      	return NULL;
	      }
	      return(rightChild);
	}
	void Node::setLeftChild(Node *ptr){
	      leftChild = ptr;
	}
	void Node::setRightChild(Node *ptr){
	      rightChild = ptr;
	}
	int Node::getHeight(){
		if(rightChild == NULL && leftChild == NULL){
			height = 1;
	        return (1);
	    }
	    if(rightChild == NULL && leftChild != NULL){
	    	height = leftChild->getHeight() + 1;
	        return leftChild->getHeight() + 1;
	    }
	    if(rightChild != NULL && leftChild == NULL){
	    	height = rightChild->getHeight() + 1;
	        return rightChild->getHeight() + 1;
	    }
	    if (rightChild != NULL && leftChild != NULL){
	        int leftH = leftChild->getHeight();
	        int rightH = rightChild->getHeight();
	        height = max(rightH,leftH) + 1;
	        return max(rightH,leftH) + 1; // max agaritam or cmath
	    }
	}