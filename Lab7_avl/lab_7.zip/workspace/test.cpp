RotateRight(Node*& n){
    Node* tmep = n->left;
    n->left = temp->right;
    temp->right = n
    n = temp;
}
Node::getHeight(){
    if (node has 0 children){
        return 1 (int);
    }
    if(Node has one child){
        return child.getHeight()+1;
    }
    if (node has 2 children){
        int leftH = left.getHeight();
        int rightH = right.getHeight();
        return max +1; // max agaritam or cmath
    }
}
void AVL::balance(Node*& n){
	int left = n->left.getHeight();
	int right = n->right.getHeight();
	int balance = right - left;
	if (balance == -2){
		if(check balance)
	} 
}
