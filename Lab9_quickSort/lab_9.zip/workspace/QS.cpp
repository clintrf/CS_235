#include "QS.h"
    void QS::sortAll() {
        if (curSize == 0) {
        return; //return nothing
        }
        sort(0, curSize - 1);
    };
    int QS::medianOfThree(int left, int right) {
        //part one
        int middle = (left + right)/2;
        //part two
        if( curSize == 0 
            || left >= right 
            || left < 0 
            || right < 0 
            || left >= curSize 
            || right >= curSize ){
            return (-1);                
        }
        else{
            if (myArray[left] > myArray[middle]) {
                MoT(left, middle);
            }
            if (myArray[middle] > myArray[right]) {
                MoT(middle, right);
            }
            if (myArray[left] > myArray[middle]) {
                MoT(left, middle);
            }
            return middle;
        }
    };
    int QS::partition(int left, int right, int pivotIndex) {
        if (curSize == 0 
            || left >= right 
            || left < 0 
            || right < 0 
            || left >= endSize 
            || right >= endSize 
            || pivotIndex < left 
            || pivotIndex > right) {
            return -1;
        }

    int pd = myArray[pivotIndex];
    int up = left + 1;
    int down = right; // avoid seg fault
    MoT(left, pivotIndex); // to switch the book code to lab specs
    do {
        while ((up != right) && !(pd < myArray[up])) {
            ++up;
        }
        while (pd < myArray[down]) {
            --down;
        }
        if (up < down) {
            MoT(up, down);
        }
    } while (up < down);
    MoT(left, down);
    return down;
    };
    string QS::getArray() const {
        if (curSize > 0){
            stringstream ss;
            for (int i = 0; i < curSize-1; i++){
                ss << myArray[i] << ",";
            }
            ss << myArray[curSize-1];
            return (ss.str());
        }
        else {
            return ("");
        }
    };
    int QS::getSize() const {
        return (curSize);
    };
    bool QS::addToArray(int value) {
        if (curSize < endSize){
            myArray[curSize] = value;
            curSize++;
            return (true);
        }
        else{
            return (false);
        }
        
    };
    bool QS::createArray(int capacity){
        if (capacity > 0){
            int* newArray = new int[capacity];
            delete[]myArray;
            myArray = newArray;
            endSize = capacity;
            curSize = 0;
            return (true);
        }
        return (false);
    };
    void QS::clear() {
        endSize = 0;
        curSize = 0;
        delete[] myArray; 
        //myArray = new int[0];
        myArray = NULL;
    };
    void QS::MoT(int ls, int rs){
        int temp =myArray[ls];
        myArray[ls] = myArray[rs];
        myArray[rs] = temp;
    };
    void QS::sort(int left, int right) {
        if (left >= right) {
            return; // return nothing
        }
        int pd = partition(left, right, medianOfThree(left, right));
        sort(left, pd - 1);
        sort(pd + 1, right);
    };