#pragma once
#include "QSInterface.h"
#include <iostream>
#include <sstream>
using namespace std;

class QS : public QSInterface {
    public:
        QS() {
            myArray = NULL;
            //myArray = new int[0];
            curSize = 0; 
            endSize = 0;
        };
        ~QS() {
            delete [] myArray;
            endSize = 0;
        };
        
        
        
        void sortAll();
        void sort(int left, int right);
        int medianOfThree(int left, int right);
        int partition(int left, int right, int pivotIndex);
        string getArray() const;
        int getSize() const;
        bool addToArray(int value);
        bool createArray(int capacity);
        void clear();
        
        void MoT(int leftSide, int rightSide);
    private:
        int *myArray;
        int curSize;
        int endSize;
};