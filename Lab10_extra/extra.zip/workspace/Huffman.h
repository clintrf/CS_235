#include "HuffmanInterface.h"
#include "TreeInterface.h"
#include "Tree.h"
#include "Node.h"
#include <set>
#include <vector>
#include <queue>
#include <map>
#include <sstream>
#include <fstream>
#include <sstream>
#include <iostream>
#include <utility>
#include <map>




class Huffman : public HuffmanInterface {
    public:
    Huffman() {};
	~Huffman() {delete myTree; tokens.clear();};

	bool createTree(string filename);
    string encodeMessage(string toEncode){
        codeMap.clear();
        encod(myTree->root, "");
        stringstream ss;
        for(int i = 0; i < toEncode.size(); i++){
            ss << codeMap[toEncode[i]];
        }
        return ss.str();
    };
	string decodeMessage(string toDecode){};
    TreeInterface * getTree();
    map<char, string> getEncodings(){
        codeMap.clear();
        encod(myTree->root, "");
        return codeMap;
    };
    void encod(Node* cur, string strr){
        if(cur->leftChild == NULL && cur->rightChild == NULL){
            codeMap[cur->getCharacter()] = strr;
            return ;
        }
        else if(cur->leftChild != NULL || cur->rightChild != NULL){
            encod(cur->leftChild, strr + "0");
            encod(cur->rightChild, strr + "1");
        }
    }

    private:
        Tree* myTree;
        map <char,int> tokens;
        map <char,string> codeMap;
};