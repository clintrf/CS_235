#include "Node.h"

	Node::Node(char character, int num){
	    this->node_char = character;
	    this->char_freq = num;
        this->leftChild = NULL;
        this->rightChild = NULL;
	};
	Node::Node(char character, int num, Node* left , Node* right){
	    this->node_char = character;
	    this->char_freq = num;
        this->leftChild = left;
        this->rightChild = right;
	};
	Node::~Node(){};
	char Node::getCharacter() const {return (this->node_char);};
	int Node::getFrequency() const {return (this->char_freq);};
	NodeInterface* Node::getLeftChild() const {return (this->leftChild);};
	NodeInterface* Node::getRightChild() const {return (this->rightChild);};