#include "Huffman.h"

	bool Huffman::createTree(string filename) {
        ifstream in(filename);
        char token;
        tokens.clear();
        priority_queue<Node*, vector<Node*>, sorter> myPriorityQueue;
        cout << myPriorityQueue.size() << endl;
        if (in.is_open() != true){
            return (false);
        }
        while (in.get(token)) {
            tokens[token]++;
        }
        for(auto f: tokens){
            myPriorityQueue.push(new Node(f.first, f.second));
        }
        while(myPriorityQueue.size() > 1){ 
            Node* a = myPriorityQueue.top();
            myPriorityQueue.pop();
            Node* b = myPriorityQueue.top();
            myPriorityQueue.pop();
            myPriorityQueue.push(new Node('\0' , a->getFrequency() + b->getFrequency(), a , b ));
            
        }
        this->myTree = new Tree(myPriorityQueue.top());
        myPriorityQueue.pop();
        return (true);
    };
    
    TreeInterface * Huffman::getTree(){
        if (this->myTree != NULL){
            return ( this->myTree );
        }
        else {
            return (NULL);
        }
    };