#include "TreeInterface.h"
#include "Node.h"

class Tree : public TreeInterface{
	friend class Huffman;
    public:
	Tree(Node* root);
	~Tree(){ root = NULL;};
	NodeInterface * getRootNode() const;
	private:
	Node* root;
};