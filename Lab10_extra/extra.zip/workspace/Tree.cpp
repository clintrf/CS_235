#include "Tree.h"
    
    Tree::Tree(Node* root){
        this->root = root;
    };
	NodeInterface * Tree::getRootNode() const{
	    return (this->root);
	};