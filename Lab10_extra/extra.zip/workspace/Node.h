#include "NodeInterface.h"
#include <queue>

#pragma once

#include <iostream>
using namespace std;

class Node : public NodeInterface {
	friend class Huffman;
public:
	Node(char character, int char_num);
	Node(char character, int char_num, Node* left, Node* right);
	~Node();
	char getCharacter() const;
	int getFrequency() const;
	NodeInterface* getLeftChild() const;
	NodeInterface* getRightChild() const;
	
protected:
    Node *leftChild;
    Node *rightChild;
    char node_char;
    int char_freq;
};