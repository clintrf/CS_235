#include <set>
#include <vector>
#include <map>
#include <sstream>
#include <fstream>
#include <iostream>
#include <utility>
#include <deque>
using namespace std;
int main(int argc, char *argv[]) 
{
 
    vector<string> tokens;
    string next_line;  // Each data line
    ifstream in(argv[1]);
    while (getline(in, next_line)) {
        istringstream iss(next_line);
        string token;
        while (iss >> token) {
            string nopunct = "";
            for(auto &c : token) { // Remove Punctuation      
                if (isalpha(c)) {
                    nopunct +=c;       
                }
            }
	        tokens.push_back(nopunct);
	    }
    }
    cout << "Number of words "<<tokens.size()<<endl;

    char c = *argv[2];
    int numOfClosness;
    numOfClosness = static_cast<int>(c-48);
    cout << "num of closness " << numOfClosness << endl; //int numOfClosness = 2) // 1 = not close, 4 = very close to text
    
    // maps
   map <deque <string>, vector <string>> wordmap;
    deque <string> last;
    for (int i = 0; i < numOfClosness; i++){
       last.push_back(""); 
    }

    for (auto s:tokens){
        wordmap[last].push_back(s);
        last.pop_front();
        last.push_back(s);
        
    }
        //Now generate text
    deque <string> current;
    for (int i = 0; i < numOfClosness; i++){
       current.push_back(""); 
    }
    
    for(int i =0; i < 100; i++) {
        if (wordmap[current].size() != 0){
            int ind = rand() % wordmap[current].size();
            cout << wordmap[current][ind]<<" ";
            current.push_back(wordmap[current][ind]);
            current.pop_front();
        }
    }
    cout << endl;
}
